CREATE INDEX test_fb ON test (f, b);

CREATE UNIQUE INDEX test_f_unique ON test (f);
