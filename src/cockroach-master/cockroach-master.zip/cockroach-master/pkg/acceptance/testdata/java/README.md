## Java acceptance test

On Mac, you can install Java and Maven with:

```sh
brew cask install java
brew install maven
```

Run `mvn install` in this directory to get the jars locally for IDE support.

Run `mvn test` to run the tests.
