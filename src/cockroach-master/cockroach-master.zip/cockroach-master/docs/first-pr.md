# Submitting your first PR

This guide has been migrated to:
https://wiki.crdb.io/wiki/spaces/CRDB/pages/181633464/Your+first+CockroachDB+PR
