# Documentation

This directory contains our [Design](design.md) document and some internal notes. You can find our client-facing technical documentation in the [docs](https://github.com/cockroachdb/docs) repository. 
