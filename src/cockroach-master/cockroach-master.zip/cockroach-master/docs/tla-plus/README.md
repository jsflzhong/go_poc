# TLA+ in CockroachDB

## About TLA+

TLA+ is a formal specification and verification language to help engineers design, specify, reason about, and verify complex software and hardware systems. It is widely used to verify the algorithms in distributed systems.

For further information about TLA+, see [tla-plus-resources](https://github.com/cmschmtt/tla-plus-resources).

