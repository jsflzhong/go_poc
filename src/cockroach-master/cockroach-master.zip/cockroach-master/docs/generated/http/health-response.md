

<a name="cockroach.server.serverpb.HealthResponse"></a>
#### HealthResponse

HealthResponse is the response to HealthRequest. It currently does not
contain any information.

Support status: [public](#support-status)



