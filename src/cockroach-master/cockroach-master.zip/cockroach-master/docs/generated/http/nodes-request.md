

<a name="cockroach.server.serverpb.NodesRequest"></a>
#### NodesRequest

NodesRequest requests a copy of the node information as known to gossip
and the KV layer.

Support status: [alpha](#support-status)



